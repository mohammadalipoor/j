<html>
<head>
	<meta http-equiv="Content-Language" content="fa">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="X-CSRF-Token" content="40bb4d96d117a67fd75bc4828ff8bf08">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>آسان پرداخت پرشين(آپ)</title>
	<link href="css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet">
    <link href="css/previewnew.css" rel="stylesheet">
    <link href="css/bootstrap/font-awesome.min.css" rel="stylesheet">
	<link href="css/jquery.keypadnew.css" rel="stylesheet" type="text/css">	
    <!--[if IE 7]>
        <link href="css/bootstrap/font-awesome-ie7.min.css" rel="stylesheet" />
    <![endif]-->
    <!--[if IE 8]>
        <style type="text/css">
        .navbar-inner{
            filter:none;
        }
         </style>
        <![endif]-->
<style type="text/css">
/*
.modal-loading-bar { 
    position: fixed;
    top: 50% !important; 
    right: 50% !important; 
    margin-top: -100px;  
    margin-left: -200px; 
    overflow: visible !important;
}
*/
.modal-loading-bar{
	position: fixed;
	left: 50%;
	top: 50%;
	margin-top: -100px;
	margin-left: -150px;
}
.modal-loading-bar .modal-content {
    width: 300px; 
    height: 60px; 
	direction:rtl;
}
.progress .progress-bar.six-sec-ease-in-out {	
    -webkit-transition: width 6s ease-in-out;
    -moz-transition: width 6s ease-in-out;
    -ms-transition: width 6s ease-in-out;
    -o-transition: width 6s ease-in-out;
    transition: width 6s ease-in-out;
}

hr.message-inner-separator
{
    clear: both;
    margin-top: 10px;
    margin-bottom: 13px;
    border: 0;
    height: 1px;
    background-image: -webkit-linear-gradient(left,rgba(0, 0, 0, 0),rgba(0, 0, 0, 0.15),rgba(0, 0, 0, 0));
    background-image: -moz-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
    background-image: -ms-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
    background-image: -o-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
}
.alert{
	margin:10px;
	font-family:IRANSans; 
	font-weight:bold; 
	font-size:11px;
	text-align:right;
	direction:rtl
}
h3,h4{ 
 font-family:IRANSans; 
 direction:rtl
}
button.btn{ 
font-family:IRANSans; 
font-weight:bold; 
font-size:11px;
 margin-top:10px;
}
.btn-label {position: relative;right: -12px;display: inline-block;padding: 6px 8px 4px;background: rgba(0,0,0,0.15);}
.btn-labeled {padding-top: 0;padding-bottom: 0;}

.flat .plan {
  width:300px;
  margin:20px auto;
  border-radius: 6px;
  list-style: none;
  padding: 0 0 20px;
  background: #fff;
  text-align: center;
}
.flat .plan li {
  padding: 10px 15px;
  color: #000;
  border-top: 0;
  -webkit-transition: 300ms;
  transition: 300ms;
}
.flat .plan li.plan-price {
  border-top: 0;
}
.flat .plan li.plan-name {
  border-radius: 6px 6px 0 0;
  padding: 15px;
font-family:IRANSans; 
font-size:16px;
  line-height: 28px;
  color: #fff;
  background: #468847;
  direction:rtl;
  margin-bottom: 0;
  border-top: 0;
}
.flat .plan li.plan-red {
  border-radius: 6px 6px 0 0;
  padding: 15px;
	font-family:IRANSans; 
	font-size:16px;
  line-height: 28px;
  color: #fff;
  background: #e74c3c;
  direction:rtl;
  margin-bottom: 0;
  border-top: 0;
}

.headlogo img{
	height: 120px;
}


@media (max-width: 767px) {
	.tabbable.custom-tabs>.nav-tabs>li>a{
		min-width:10px;
		padding:15px 10px 10px;
	}
	.tabbable.custom-tabs>.nav-tabs>li>a>span{
		display: none
	}
	.headlogo img{
		display: block; 
		max-width: 100%; 
		height: 60px;
	}	
}

.ipgheader{
		background-image: url(img/topbarnew.jpg);
		background-position: 100% auto;
		background-repeat: no-repeat;
		background-size: contain;
		position: relative;
		padding-bottom: 7.5%;
	}
	input:focus:invalid:focus,textarea:focus:invalid:focus,select:focus:invalid:focus{
		border-color:#66afe9;
		-webkit-box-shadow:0 0 6px #66afe9;
		-moz-box-shadow:0 0 6px #66afe9;
		box-shadow:0 0 6px #66afe9;
		color:#000;
	}
/*.modal-loading-bar{
	position: absolute;
	top: 50%;
	left: 50%;
	margin-top: -50px;
	margin-left: -150px;	
}
*/
.BacktoMerchantSite{
	position: absolute;
	top: 50%;
	left: 50%;
	margin-left: -150px;
	margin-top: -100px;
	width: 300px;
	height: 100px;
	padding: 32px 0 28px;	
	text-align: center; 
	line-height: 18pt; 
	font-size:12px; 
	word-spacing: -1px;
}		
.PasswordStyleInput {
    -webkit-text-security: disc;
    }
</style>		
<script type="text/javascript">
//<![CDATA[
window["_tsbp_"] = { ba : "X-TS-BP-Action", bh : "X-TS-AJAX-Request"};
//]]>
</script><script type="text/javascript" src="/TSbd/08bb6282b4ab200025954e2d3cc05f984deb59daf4ef4b59b822f62767f436f0533ff993e0b8c6aa?type=2"></script></head>
<body>
<div id="OutputTxt" class="alert alert-danger"><i class="icon-warning-sign" style="font-size:24px; padding-left:5px"></i>پرداخت شما لغو شد.</div>
</body>
</html>